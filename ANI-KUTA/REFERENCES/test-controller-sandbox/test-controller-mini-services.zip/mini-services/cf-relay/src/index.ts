/**
 * ANI-KUTA Test Controller — Cloudflare Workers WebSocket relay (D-198 v4).
 *
 * Architecture:
 *   - The Worker (serverless, edge) routes WebSocket upgrades to a Durable Object.
 *   - The Durable Object ("RelayRoom") holds both the phone + agent connections.
 *   - WebSocket Hibernation API: idle connections hibernate server-side ($0 cost).
 *     When a message arrives, the DO wakes in ~5ms.
 *
 * Flow:
 *   Agent (Python) ──ws──► Worker ──► DO("main") ◄──ws── Phone (Android)
 *                              │
 *                    DO forwards messages:
 *                    kind:"command" → phone
 *                    kind:"result" → agent
 *                    kind:"screenshot" → agent
 *                    kind:"ping" → phone (expects pong)
 *
 * URL: wss://anikuta-relay.<account-subdomain>.workers.dev/
 *
 * Deploy: `CLOUDFLARE_API_TOKEN=... npx wrangler deploy`
 */

export interface Env {
  RELAY_ROOM: DurableObjectNamespace;
}

// ── Worker (stateless router) ──

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // Health check endpoint (HTTP, no WebSocket).
    if (url.pathname === "/state") {
      // Forward to the DO to get live connection status.
      const id = env.RELAY_ROOM.idFromName("main");
      const stub = env.RELAY_ROOM.get(id);
      try {
        return await stub.fetch(new Request("https://do/state"));
      } catch {
        return new Response(JSON.stringify({ relay: "starting", phoneConnected: false }), {
          headers: { "content-type": "application/json" },
        });
      }
    }

    // Root — info page (HTTP).
    if (url.pathname === "/" && request.headers.get("Upgrade") !== "websocket") {
      return new Response(
        "ANI-KUTA Test Relay — WebSocket endpoint at wss://" + url.host + "/\n" +
        "Health: https://" + url.host + "/state",
        { status: 200, headers: { "content-type": "text/plain" } },
      );
    }

    // WebSocket upgrade — route to the Durable Object "main" room.
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Expected WebSocket upgrade", { status: 426 });
    }

    const id = env.RELAY_ROOM.idFromName("main");
    const stub = env.RELAY_ROOM.get(id);
    return stub.fetch(request);
  },
};

// ── Durable Object (stateful relay room) ──

interface SessionMeta {
  role: "phone" | "agent" | "unknown";
  connectedAt: number;
}

export class RelayRoom implements DurableObject {
  private sessions = new Map<WebSocket, SessionMeta>();

  constructor(private ctx: DurableObjectState, private env: Env) {
    // Rebuild the sessions map from hibernated connections (state is lost on hibernation).
    for (const ws of this.ctx.getWebSockets()) {
      const meta = ws.deserializeAttachment() as SessionMeta | null;
      this.sessions.set(ws, meta ?? { role: "unknown", connectedAt: Date.now() });
    }
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    // Health check from the Worker.
    if (url.pathname === "/state") {
      let phoneCount = 0;
      let agentCount = 0;
      for (const meta of this.sessions.values()) {
        if (meta.role === "phone") phoneCount++;
        else if (meta.role === "agent") agentCount++;
      }
      return new Response(JSON.stringify({
        relay: "running",
        phoneConnected: phoneCount > 0,
        phoneCount,
        agentCount,
        totalConnections: this.sessions.size,
      }), { headers: { "content-type": "application/json" } });
    }

    // WebSocket upgrade.
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Expected WebSocket", { status: 426 });
    }

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    // Store metadata on the connection (survives hibernation via serializeAttachment).
    const meta: SessionMeta = { role: "unknown", connectedAt: Date.now() };
    this.sessions.set(server, meta);
    server.serializeAttachment(meta);

    // Accept with Hibernation API — connection hibernates when idle ($0 cost).
    this.ctx.acceptWebSocket(server);

    return new Response(null, { status: 101, webSocket: client });
  }

  // ── Hibernation API callbacks ──

  async webSocketMessage(ws: WebSocket, message: ArrayBuffer | string): Promise<void> {
    const msgStr = typeof message === "string" ? message : new TextDecoder().decode(message);
    let msg: any;
    try {
      msg = JSON.parse(msgStr);
    } catch {
      return; // Invalid JSON — ignore.
    }

    const kind = msg?.kind;
    const meta = this.sessions.get(ws) ?? { role: "unknown", connectedAt: Date.now() };

    switch (kind) {
      case "register": {
        // Client identifies as phone or agent.
        const role = msg.role === "phone" ? "phone" : msg.role === "agent" ? "agent" : "unknown";
        meta.role = role;
        this.sessions.set(ws, meta);
        ws.serializeAttachment(meta);
        if (role === "phone") {
          // Close any existing phone connection (only one phone at a time).
          for (const [existingWs, existingMeta] of this.sessions.entries()) {
            if (existingMeta.role === "phone" && existingWs !== ws) {
              try { existingWs.close(1000, "replaced by new phone"); } catch {}
              this.sessions.delete(existingWs);
            }
          }
          console.log("[relay] phone registered");
        } else if (role === "agent") {
          console.log("[relay] agent registered (transient)");
        }
        ws.send(JSON.stringify({ kind: "ack", message: `${role} registered` }));
        break;
      }

      case "command":
      case "ping": {
        // From the agent → forward to the phone.
        const phoneWs = this.findPhone();
        if (phoneWs) {
          try {
            phoneWs.send(msgStr);
          } catch (e) {
            console.error("[relay] failed to forward command to phone:", e);
            ws.send(JSON.stringify({
              kind: "result",
              id: msg.id,
              ok: false,
              type: "error",
              message: "phone send failed",
              errorType: "PHONE_SEND_FAILED",
            }));
          }
        } else {
          console.log("[relay] command received but no phone connected");
          ws.send(JSON.stringify({
            kind: "result",
            id: msg.id,
            ok: false,
            type: "error",
            message: "no phone connected",
            errorType: "NO_PHONE",
          }));
        }
        break;
      }

      case "result":
      case "pong":
      case "screenshot": {
        // From the phone → forward to all agents (usually just one).
        let forwarded = 0;
        for (const [agentWs, agentMeta] of this.sessions.entries()) {
          if (agentMeta.role === "agent" && agentWs !== ws) {
            try {
              agentWs.send(msgStr);
              forwarded++;
            } catch (e) {
              console.error("[relay] failed to forward to agent:", e);
            }
          }
        }
        if (forwarded === 0) {
          console.log(`[relay] ${kind} from phone but no agent to receive`);
        }
        break;
      }

      default: {
        // Unknown kind — try forwarding to the phone (might be a custom command).
        const phoneWs = this.findPhone();
        if (phoneWs && phoneWs !== ws) {
          try { phoneWs.send(msgStr); } catch {}
        }
      }
    }
  }

  async webSocketClose(ws: WebSocket, code: number, reason: string): Promise<void> {
    this.sessions.delete(ws);
    const meta = ws.deserializeAttachment() as SessionMeta | null;
    console.log(`[relay] ${meta?.role ?? "unknown"} disconnected: ${code} ${reason}`);
    try { ws.close(code, reason); } catch {}
  }

  async webSocketError(ws: WebSocket, error: unknown): Promise<void> {
    this.sessions.delete(ws);
    console.error("[relay] WebSocket error:", error);
    try { ws.close(1011, "WebSocket error"); } catch {}
  }

  // ── Helpers ──

  private findPhone(): WebSocket | null {
    for (const [ws, meta] of this.sessions.entries()) {
      if (meta.role === "phone") return ws;
    }
    return null;
  }
}
