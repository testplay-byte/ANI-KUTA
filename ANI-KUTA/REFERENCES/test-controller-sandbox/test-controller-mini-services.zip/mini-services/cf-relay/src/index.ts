/**
 * ANI-KUTA Test Controller — Cloudflare Workers WebSocket relay (D-198 v5.5).
 *
 * v5.5: Dashboard HTML served inline + coordinate fix + element overlay toggle.
 * v5.4: Role gating + dead session eviction + webSocketError broadcast + reconnect cascade fix.
 *
 * Deploy: `CLOUDFLARE_API_TOKEN=... npx wrangler deploy`
 */

import { DASHBOARD_HTML } from "./dashboard-html";

export interface Env {
  RELAY_ROOM: DurableObjectNamespace;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/state") {
      const id = env.RELAY_ROOM.idFromName("main");
      const stub = env.RELAY_ROOM.get(id);
      try {
        return await stub.fetch(new Request("https://do/state"));
      } catch {
        return new Response(JSON.stringify({ relay: "starting", phoneConnected: false }), {
          headers: { "content-type": "application/json" },
        });
      }
    }

    if (request.headers.get("Upgrade") === "websocket") {
      const id = env.RELAY_ROOM.idFromName("main");
      const stub = env.RELAY_ROOM.get(id);
      return stub.fetch(request);
    }

    if (url.pathname === "/" || url.pathname === "/index.html") {
      return new Response(DASHBOARD_HTML, {
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }

    return new Response("ANI-KUTA Test Relay", { status: 200 });
  },
};

interface SessionMeta {
  role: "phone" | "agent" | "dashboard" | "unknown";
  connectedAt: number;
}

export class RelayRoom implements DurableObject {
  private sessions = new Map<WebSocket, SessionMeta>();

  constructor(private ctx: DurableObjectState, private env: Env) {
    for (const ws of this.ctx.getWebSockets()) {
      const meta = ws.deserializeAttachment() as SessionMeta | null;
      this.sessions.set(ws, meta ?? { role: "unknown", connectedAt: Date.now() });
    }
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/state") {
      let phoneCount = 0, agentCount = 0, dashboardCount = 0;
      for (const meta of this.sessions.values()) {
        if (meta.role === "phone") phoneCount++;
        else if (meta.role === "agent") agentCount++;
        else if (meta.role === "dashboard") dashboardCount++;
      }
      return new Response(JSON.stringify({
        relay: "running", phoneConnected: phoneCount > 0,
        phoneCount, agentCount, dashboardCount, totalConnections: this.sessions.size,
      }), { headers: { "content-type": "application/json" } });
    }

    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Expected WebSocket", { status: 426 });
    }

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    const meta: SessionMeta = { role: "unknown", connectedAt: Date.now() };
    this.sessions.set(server, meta);
    server.serializeAttachment(meta);
    this.ctx.acceptWebSocket(server);
    return new Response(null, { status: 101, webSocket: client });
  }

  async webSocketMessage(ws: WebSocket, message: ArrayBuffer | string): Promise<void> {
    const msgStr = typeof message === "string" ? message : new TextDecoder().decode(message);
    let msg: any;
    try { msg = JSON.parse(msgStr); } catch { return; }

    const kind = msg?.kind;
    const meta = this.sessions.get(ws) ?? { role: "unknown", connectedAt: Date.now() };

    switch (kind) {
      case "register": {
        const role = msg.role === "phone" ? "phone" : msg.role === "agent" ? "agent" : msg.role === "dashboard" ? "dashboard" : "unknown";
        meta.role = role;
        this.sessions.set(ws, meta);
        ws.serializeAttachment(meta);
        if (role === "phone") {
          for (const [existingWs, existingMeta] of this.sessions.entries()) {
            if (existingMeta.role === "phone" && existingWs !== ws) {
              try { existingWs.close(1000, "replaced"); } catch {}
              this.sessions.delete(existingWs);
            }
          }
        }
        if (role === "dashboard") {
          ws.send(JSON.stringify({ kind: "status", phoneConnected: this.findPhone() !== null, agentCount: this.countRole("agent"), dashboardCount: this.countRole("dashboard") }));
        }
        ws.send(JSON.stringify({ kind: "ack", message: `${role} registered` }));
        this.broadcastToDashboards(JSON.stringify({ kind: "status", phoneConnected: this.findPhone() !== null, agentCount: this.countRole("agent"), dashboardCount: this.countRole("dashboard") }), ws);
        break;
      }

      case "command":
      case "ping": {
        if (meta.role !== "agent" && meta.role !== "dashboard") break;
        const phoneWs = this.findPhone();
        if (phoneWs) {
          try { phoneWs.send(msgStr); } catch (e) { ws.send(JSON.stringify({ kind: "result", id: msg.id, ok: false, type: "error", message: "phone send failed" })); }
        } else {
          ws.send(JSON.stringify({ kind: "result", id: msg.id, ok: false, type: "error", message: "no phone connected" }));
        }
        this.broadcastToDashboards(msgStr, ws);
        break;
      }

      case "result":
      case "pong":
      case "screenshot": {
        if (meta.role !== "phone") break;
        for (const [agentWs, agentMeta] of this.sessions.entries()) {
          if (agentMeta.role === "agent" && agentWs !== ws) {
            try { agentWs.send(msgStr); } catch { this.sessions.delete(agentWs); }
          }
        }
        this.broadcastToDashboards(msgStr, ws);
        break;
      }

      default: {
        if (meta.role !== "agent" && meta.role !== "dashboard") break;
        const phoneWs = this.findPhone();
        if (phoneWs && phoneWs !== ws) { try { phoneWs.send(msgStr); } catch {} }
      }
    }
  }

  async webSocketClose(ws: WebSocket, code: number, reason: string): Promise<void> {
    this.sessions.delete(ws);
    try { ws.close(code, reason); } catch {}
    this.broadcastToDashboards(JSON.stringify({ kind: "status", phoneConnected: this.findPhone() !== null, agentCount: this.countRole("agent"), dashboardCount: this.countRole("dashboard") }), null);
  }

  async webSocketError(ws: WebSocket, error: unknown): Promise<void> {
    this.sessions.delete(ws);
    try { ws.close(1011, "error"); } catch {}
    this.broadcastToDashboards(JSON.stringify({ kind: "status", phoneConnected: this.findPhone() !== null, agentCount: this.countRole("agent"), dashboardCount: this.countRole("dashboard") }), null);
  }

  private findPhone(): WebSocket | null {
    for (const [ws, meta] of this.sessions.entries()) { if (meta.role === "phone") return ws; }
    return null;
  }

  private countRole(role: string): number {
    let c = 0; for (const m of this.sessions.values()) { if (m.role === role) c++; } return c;
  }

  private broadcastToDashboards(msgStr: string, excludeWs: WebSocket | null): void {
    for (const [dashWs, dashMeta] of this.sessions.entries()) {
      if (dashMeta.role === "dashboard" && dashWs !== excludeWs) {
        try { dashWs.send(msgStr); } catch { this.sessions.delete(dashWs); }
      }
    }
  }
}
