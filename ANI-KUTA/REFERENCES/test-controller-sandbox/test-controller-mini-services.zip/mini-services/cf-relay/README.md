# ANI-KUTA Test Relay — Cloudflare Workers

A WebSocket relay running on Cloudflare Workers + Durable Objects. Connects the AI agent (Python, sandbox) to the ANI-KUTA Android app on the user's phone.

## Why Cloudflare Workers?

- **Stable URL** — `wss://anikuta-relay.<your-subdomain>.workers.dev/` (permanent, never changes)
- **Always-on** — Durable Objects with WebSocket Hibernation (idle connections cost $0)
- **Port 443** — no carrier blocks (unlike MQTT ports)
- **Free tier** — 100K requests/day, 13K GB-s/day (plenty for testing)
- **32MB payload** — screenshots (50-200KB) fit easily
- **No server management** — Cloudflare handles scaling + uptime (99.9% SLA)

## Architecture

```
Agent (Python) ──ws──► Cloudflare Worker ──► Durable Object "main"
                                              ├─ phone WebSocket (persistent)
                                              └─ agent WebSocket (transient)
                         DO forwards:
                         kind:"command" → phone
                         kind:"result" → agent
                         kind:"screenshot" → agent
```

## Deployment — 2 options

### Option A: I deploy from the sandbox (requires your Cloudflare API token)

1. **Create a Cloudflare account** (free): https://dash.cloudflare.com/sign-up
2. **Create an API token**:
   - Go to: https://dash.cloudflare.com/profile/api-tokens
   - Click "Create Token" → "Edit Cloudflare Workers" template → "Continue to summary" → "Create Token"
   - Copy the token (starts with `cf_...`)
3. **Give me the token** — paste it in chat. I'll run `wrangler deploy` from the sandbox.
4. I'll get the URL (`anikuta-relay.<your-subdomain>.workers.dev`) + configure everything.

### Option B: You deploy via the Cloudflare Dashboard (no token sharing)

1. **Create a Cloudflare account** (free): https://dash.cloudflare.com/sign-up
2. Go to **Workers & Pages** → **Create application** → **Create Worker**
3. Name it `anikuta-relay` → click **Deploy**
4. Go to **Edit code** → paste the contents of `src/index.ts` (from this folder) → click **Deploy**
5. **Enable Durable Objects** (requires the Wrangler CLI for the migration):
   - Install Node.js + `npm install -g wrangler`
   - `wrangler login` (opens browser)
   - Copy this folder to your machine
   - `cd cf-relay && wrangler deploy`
6. Give me the URL (`anikuta-relay.<your-subdomain>.workers.dev`)

### Option C: Use the Cloudflare AI to guide you

Paste this prompt into the Cloudflare AI (or ChatGPT/Claude):

```
I need to deploy a WebSocket relay on Cloudflare Workers using Durable Objects.
The relay accepts WebSocket connections at wss://<worker-name>.<my-subdomain>.workers.dev/
and routes messages between two clients (a "phone" and an "agent") based on a "kind"
field in the JSON messages.

Guide me step-by-step:
1. How to create a Cloudflare account (free)
2. How to install the Wrangler CLI
3. How to create a Worker project with a Durable Object binding
4. The exact wrangler.toml config needed (with [[durable_objects.bindings]] + [[migrations]] using new_sqlite_classes)
5. How to deploy with `wrangler deploy`
6. How to get the resulting wss:// URL

I already have the Worker code (a TypeScript file). I just need the deployment steps.
```

## Files

```
cf-relay/
├── wrangler.toml     # Cloudflare Worker config (DO bindings, migrations)
├── package.json      # npm deps (wrangler, @cloudflare/workers-types)
├── tsconfig.json     # TypeScript config
└── src/
    └── index.ts      # Worker (router) + RelayRoom (Durable Object with WebSocket Hibernation)
```

## Local development

```bash
cd /home/z/my-project/mini-services/cf-relay
npm install
npx wrangler dev   # starts a local dev server on :8787
```

Test with `wscat`:
```bash
npm install -g wscat
wscat -c ws://localhost:8787/
> {"kind":"register","role":"agent"}
> {"kind":"ping","id":"test1"}
```

## Deploy

```bash
# Set your API token (get it from https://dash.cloudflare.com/profile/api-tokens)
export CLOUDFLARE_API_TOKEN="cf_your_token_here"

# Deploy
cd /home/z/my-project/mini-services/cf-relay
npx wrangler deploy

# Output:
# Published anikuta-relay (x.xx sec)
#   https://anikuta-relay.<your-subdomain>.workers.dev
#   wss://anikuta-relay.<your-subdomain>.workers.dev
```

## Verify deployment

```bash
# Health check
curl https://anikuta-relay.<your-subdomain>.workers.dev/state
# → {"relay":"running","phoneConnected":false,...}

# Or via the agent helper:
export RELAY_URL="wss://anikuta-relay.<your-subdomain>.workers.dev/"
cd /home/z/my-project/mini-services/agent-bridge
./agent.sh relay_status
```

## How it works (technical)

### WebSocket Hibernation API

Traditional WebSocket servers keep the event loop running for each connection — expensive. Cloudflare's Hibernation API (`ctx.acceptWebSocket(ws)`) lets the DO hibernate when idle. When a message arrives, the DO wakes in ~5ms.

- **Cost**: Idle connections = $0 (no CPU time). Only `webSocketMessage` invocations count.
- **State**: In-memory state is wiped on hibernation. Rebuild it in the constructor from `ctx.getWebSockets()` + `deserializeAttachment()`.
- **Free tier**: 100K requests/day. WebSocket messages are billed at 20:1 (100 messages = 5 billed requests). At ~1000 messages/day testing, that's 50 billed requests — 0.05% of the free tier.

### Message routing

The DO routes by the `kind` field in each JSON message:

| `kind` | From | To | Purpose |
|---|---|---|---|
| `register` | both | — | Identify as phone or agent |
| `command` | agent | phone | A TestCommand to execute |
| `ping` | agent | phone | Smoke test |
| `result` | phone | agent | Command result |
| `pong` | phone | agent | Ping response |
| `screenshot` | phone | agent | Base64 JPEG screenshot |

### Single-phone enforcement

Only one phone can be connected at a time. If a new phone registers, the old phone's connection is closed (1000, "replaced by new phone"). This prevents stale connections.

## Pricing (free tier)

| Resource | Free tier | Our usage | Headroom |
|---|---|---|---|
| Requests/day | 100,000 | ~2,000 | 50× |
| GB-seconds/day | 13,000 | ~100 | 130× |
| SQLite storage | 5 GB | <1 MB | 5000× |
| WebSocket connections | Unlimited (hibernated) | 2 | ∞ |

**Cost: $0/month** even at 10× current usage.
