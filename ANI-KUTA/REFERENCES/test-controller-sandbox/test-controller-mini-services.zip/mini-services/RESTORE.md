# ANI-KUTA Test Controller — Mini-Services (Sandbox-Side) v5.6.1

## How to restore after a sandbox clear
1. Copy to /home/z/my-project/mini-services/
2. cd cf-relay && npm install && pip install --break-system-packages websockets
3. Create cf-relay/.env with tokens
4. chmod +x agent-bridge/agent.sh
5. Deploy: cd cf-relay && npx wrangler deploy
6. Test: export RELAY_URL=wss://anikuta-relay.anikuta.workers.dev/ && agent-bridge/agent.sh ping
