# ANI-KUTA Test Controller — Mini-Services (Sandbox-Side)

This folder contains the sandbox-side components of the test-controller system.
These files are NOT part of the Android app — they run in the AI agent's sandbox
environment to relay commands between the agent and the phone.

## How to restore after a sandbox clear

1. Copy this folder to `/home/z/my-project/mini-services/`:
   ```bash
   cp -r mini-services /home/z/my-project/
   ```

2. Install dependencies:
   ```bash
   cd /home/z/my-project/mini-services/cf-relay
   npm install
   pip install --break-system-packages websockets
   ```

3. Create the credentials file (NOT in this zip — contains API tokens):
   ```bash
   cat > /home/z/my-project/mini-services/cf-relay/.env << 'ENVEOF'
   CLOUDFLARE_API_TOKEN=<get from user>
   CLOUDFLARE_ACCOUNT_ID=b073e9f3898336783a15aa371381f96e
   GITHUB_TOKEN=<get from user>
   GITHUB_REPO=testplay-byte/ANI-KUTA
   GITHUB_BRANCH=TEST_BETA_FEATURE
   RELAY_URL=wss://anikuta-relay.k-h-u-r-r-a-m-n-o-o-r88888888888.workers.dev/
   ENVEOF
   chmod 600 /home/z/my-project/mini-services/cf-relay/.env
   ```

4. Make agent.sh executable:
   ```bash
   chmod +x /home/z/my-project/mini-services/agent-bridge/agent.sh
   ```

5. Test connectivity:
   ```bash
   export RELAY_URL="wss://anikuta-relay.k-h-u-r-r-a-m-n-o-o-r88888888888.workers.dev/"
   cd /home/z/my-project/mini-services/agent-bridge
   ./agent.sh relay_status
   ./agent.sh ping
   ```

## Does the AI agent need the Cloudflare token?

**NO.** The agent only needs the relay URL (hardcoded in agent.sh). The Cloudflare
API token is ONLY needed for:
- Deploying/redeploying the Worker (`wrangler deploy`)
- Viewing real-time logs (`wrangler tail`)
- Deleting the Worker

The agent connects to the relay as a WebSocket client — no authentication needed.

## What's in here

### agent-bridge/ — Agent-side one-shot WebSocket client
- `ws-agent.py` — Python one-shot client (connect → send → receive → disconnect per command)
- `agent.sh` — Bash helper (ping, get_state, tap, swipe, db_tables, etc.)
- `mqtt-agent.py` — Legacy MQTT client (not used with Cloudflare Workers)
- `mqtt-agent.ts` — Legacy Bun MQTT client (not used — Bun doesn't support ws.createWebSocketStream)
- `src/index.ts` — Legacy Bun HTTP relay (not used with Cloudflare Workers)

### cf-relay/ — Cloudflare Workers WebSocket relay
- `src/index.ts` — Worker (stateless router) + RelayRoom (Durable Object with Hibernation API)
- `wrangler.toml` — Cloudflare config (DO binding, migration, compatibility_date)
- `package.json` — npm deps (wrangler, @cloudflare/workers-types)
- `tsconfig.json` — TypeScript config
- `README.md` — Deployment guide

### nextjs-api/ — Legacy Next.js API route (reference only)
- `route.ts` — The original Next.js relay (replaced by Cloudflare Workers)
