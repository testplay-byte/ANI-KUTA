# ANI-KUTA Test Controller — Mini-Services (Sandbox-Side) v5.5

## How to restore after a sandbox clear

1. Copy this folder to /home/z/my-project/mini-services/
2. Install deps: cd cf-relay && npm install && pip install --break-system-packages websockets
3. Create cf-relay/.env with CLOUDFLARE_API_TOKEN + CLOUDFLARE_ACCOUNT_ID + GITHUB_TOKEN
4. chmod +x agent-bridge/agent.sh
5. Deploy Worker: cd cf-relay && CLOUDFLARE_API_TOKEN=... npx wrangler deploy
6. Test: export RELAY_URL=wss://anikuta-relay.anikuta.workers.dev/ && agent-bridge/agent.sh ping

## What's in here (v5.5)
- agent-bridge/ — Python ws-agent.py + agent.sh (shell-injection-safe JSON)
- cf-relay/ — Worker (role gating + dead session eviction + webSocketError broadcast)
  - public/index.html — Dashboard (draggable panels, clickable screenshot, element overlay toggle, coordinate fix)
  - src/dashboard-html.ts — Embedded HTML for inline serving
- nextjs-api/ — Legacy Next.js API route (reference only)

## Does the AI agent need the Cloudflare token?
NO. The agent only needs the relay URL (hardcoded in agent.sh).
