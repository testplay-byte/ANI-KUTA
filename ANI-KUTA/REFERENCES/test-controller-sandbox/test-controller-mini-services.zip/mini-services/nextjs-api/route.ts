import { NextRequest, NextResponse } from "next/server";
import { WebSocketServer, WebSocket } from "ws";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * ANI-KUTA Test Controller — WebSocket relay starter + health check.
 *
 * GET  /api/test-relay        → starts the relay (if not running) + returns status.
 * POST /api/test-relay        → same (alias for convenience).
 *
 * The relay runs on port 3030 inside the Next.js dev server process (persistent —
 * survives across Bash tool calls because the dev server is the sandbox's main process).
 * The phone connects via wss://PUBLIC_URL/?XTransformPort=3030.
 * The agent connects via ws://localhost:3030 to send commands.
 *
 * D-198 v3: replaced MQTT with a sandbox-hosted WebSocket relay for reliability.
 */

const PORT = 3030;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let relayServer: WebSocketServer | null = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let phoneSocket: WebSocket | null = null;
const agentWaiters = new Map<string, WebSocket>(); // commandId → agent ws

type RelayMessage =
  | { kind: "command"; id: string; type: string; [key: string]: unknown }
  | { kind: "result"; id: string; ok: boolean; type: string; [key: string]: unknown }
  | { kind: "screenshot"; id: string; data: string }
  | { kind: "register"; role: "phone" | "agent" }
  | { kind: "ping"; id: string }
  | { kind: "pong"; id: string; deviceInfo?: unknown; navKey?: string };

function startRelay(): { ok: boolean; error?: string } {
  if (relayServer) return { ok: true };
  try {
    relayServer = new WebSocketServer({ port: PORT, clientTracking: true });

    // Heartbeat: every 15s, ping all clients. If a client doesn't respond with
    // a pong within the next cycle, terminate it (detects dead connections).
    // This fixes the 'stale phoneSocket' issue where the relay thinks the phone
    // is connected but the socket is actually dead (Android killed the service).
    const heartbeatInterval = setInterval(() => {
      relayServer?.clients.forEach((ws: WebSocket) => {
        // @ts-expect-error - isAlive is a custom property we set
        if (ws.isAlive === false) {
          console.log("[test-relay] heartbeat: terminating dead connection");
          ws.terminate();
          return;
        }
        // @ts-expect-error - isAlive is a custom property we set
        ws.isAlive = false;
        ws.ping();
      });
      // Also check phoneSocket explicitly
      if (phoneSocket && phoneSocket.readyState !== WebSocket.OPEN) {
        console.log("[test-relay] phoneSocket not OPEN — clearing");
        phoneSocket = null;
      }
    }, 15_000);

    relayServer.on("connection", (ws: WebSocket) => {
      console.log("[test-relay] WebSocket client connected");
      // @ts-expect-error - isAlive is a custom property for heartbeat
      ws.isAlive = true;
      ws.on("pong", () => {
        // @ts-expect-error - isAlive is a custom property for heartbeat
        ws.isAlive = true;
      });

      ws.on("message", (data: Buffer) => {
        const msgStr = data.toString("utf-8");
        let msg: RelayMessage;
        try {
          msg = JSON.parse(msgStr);
        } catch {
          console.log("[test-relay] invalid JSON:", msgStr.slice(0, 100));
          return;
        }

        switch (msg.kind) {
          case "register": {
            if (msg.role === "phone") {
              // If there's an existing phone socket, close it.
              if (phoneSocket && phoneSocket.readyState === WebSocket.OPEN) {
                phoneSocket.close();
              }
              phoneSocket = ws;
              console.log("[test-relay] phone registered");
              ws.send(JSON.stringify({ kind: "ack", message: "phone registered" }));
            } else {
              console.log("[test-relay] agent registered (transient)");
            }
            break;
          }
          case "command": {
            if (phoneSocket && phoneSocket.readyState === WebSocket.OPEN) {
              console.log(`[test-relay] forwarding command ${msg.id} to phone`);
              agentWaiters.set(msg.id, ws);
              phoneSocket.send(msgStr);
            } else {
              console.log("[test-relay] command received but no phone connected");
              ws.send(JSON.stringify({
                kind: "result",
                id: msg.id,
                ok: false,
                type: "error",
                message: "no phone connected",
                errorType: "NO_PHONE",
              }));
            }
            break;
          }
          case "result": {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const agentWs = agentWaiters.get((msg as any).id);
            if (agentWs && agentWs.readyState === WebSocket.OPEN) {
              console.log(`[test-relay] forwarding result ${(msg as any).id} to agent`);
              // Forward the raw message (includes kind:"result" + the TestResult fields).
              // The agent's JSON parser has ignoreUnknownKeys=true so the extra "kind" field is OK.
              agentWs.send(msgStr);
              agentWaiters.delete((msg as any).id);
            }
            break;
          }
          case "screenshot": {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const agentWs = agentWaiters.get((msg as any).id);
            if (agentWs && agentWs.readyState === WebSocket.OPEN) {
              console.log(`[test-relay] forwarding screenshot ${(msg as any).id} to agent`);
              agentWs.send(msgStr);
            }
            break;
          }
          case "ping": {
            if (phoneSocket && phoneSocket.readyState === WebSocket.OPEN) {
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              agentWaiters.set((msg as any).id, ws);
              phoneSocket.send(msgStr);
            } else {
              ws.send(JSON.stringify({
                kind: "result",
                id: (msg as any).id,
                ok: false,
                type: "error",
                message: "no phone connected",
                errorType: "NO_PHONE",
              }));
            }
            break;
          }
          case "pong": {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const agentWs = agentWaiters.get((msg as any).id);
            if (agentWs && agentWs.readyState === WebSocket.OPEN) {
              agentWs.send(msgStr);
              agentWaiters.delete((msg as any).id);
            }
            break;
          }
          default: {
            if (phoneSocket && phoneSocket.readyState === WebSocket.OPEN && (msg as any).id) {
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              agentWaiters.set((msg as any).id, ws);
              phoneSocket.send(msgStr);
            }
          }
        }
      });

      ws.on("close", () => {
        if (phoneSocket === ws) {
          phoneSocket = null;
          console.log("[test-relay] phone disconnected");
        }
        console.log("[test-relay] WebSocket client disconnected");
      });

      ws.on("error", (err: Error) => {
        console.error("[test-relay] ws error:", err.message);
      });
    });

    console.log(`[test-relay] listening on ws://localhost:${PORT}`);
    return { ok: true };
  } catch (e) {
    const err = e as Error;
    console.error("[test-relay] failed to start:", err.message);
    return { ok: false, error: err.message };
  }
}

export async function GET(req: NextRequest) {
  const result = startRelay();
  return NextResponse.json({
    relay: result.ok ? "running" : "failed",
    error: result.error,
    phoneConnected: phoneSocket !== null && phoneSocket.readyState === WebSocket.OPEN,
    waitingAgents: agentWaiters.size,
    port: PORT,
    wsPath: "/",
    note: result.ok
      ? "WebSocket relay is running. Phone connects via wss://PUBLIC_URL/?XTransformPort=3030. Agent connects via ws://localhost:3030."
      : `Failed to start: ${result.error}`,
  });
}

export async function POST(req: NextRequest) {
  return GET(req);
}
