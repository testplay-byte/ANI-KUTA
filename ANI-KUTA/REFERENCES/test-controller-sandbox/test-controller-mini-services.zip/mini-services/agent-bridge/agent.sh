#!/usr/bin/env bash
# ANI-KUTA Test Controller — agent helper (D-198 v4, Cloudflare Workers).
#
# One-shot WebSocket client. Connects to the relay, sends a command, waits for
# the result (+ screenshot), writes to local files, disconnects.
#
# The relay URL is set via the RELAY_URL env var:
#   - For Cloudflare Workers: export RELAY_URL="wss://anikuta-relay.xxx.workers.dev/"
#   - For local Next.js relay: export RELAY_URL="ws://127.0.0.1:3030/"
#
# Usage:
#   ./agent.sh send '<json>'         # send a command
#   ./agent.sh ping                  # smoke test
#   ./agent.sh get_state             # UI state + screenshot
#   ./agent.sh relay_status          # check relay + phone status
set -euo pipefail

BRIDGE_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA="$BRIDGE_DIR/data"

# Relay URL: Cloudflare Workers (preferred) or local Next.js (fallback).
RELAY_URL="${RELAY_URL:-ws://127.0.0.1:3030/}"

# For local Next.js relay, ensure it's running.
if [[ "$RELAY_URL" == *"localhost"* ]] || [[ "$RELAY_URL" == *"127.0.0.1"* ]]; then
  curl -s --max-time 3 http://localhost:3000/api/test-relay > /dev/null 2>&1 || true
fi

cmd="${1:-help}"
shift || true

case "$cmd" in
  send)
    json_payload="${1:?usage: send '<json>'}"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "$json_payload" "$RELAY_URL"
    ;;
  ping)
    id="ping-$(date +%s%N | cut -c1-16)"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"ping\",\"id\":\"$id\"}" "$RELAY_URL"
    ;;
  get_state)
    id="state-$(date +%s%N | cut -c1-16)"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"get_state\",\"id\":\"$id\",\"includeScreenshot\":true}" "$RELAY_URL"
    echo "[agent] screenshot at: $DATA/screenshots/$id.png" >&2
    ;;
  screenshot)
    id="shot-$(date +%s%N | cut -c1-16)"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"screenshot\",\"id\":\"$id\"}" "$RELAY_URL"
    echo "[agent] screenshot at: $DATA/screenshots/$id.png" >&2
    ;;
  back)
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"back\",\"id\":\"back-$(date +%s)\"}" "$RELAY_URL"
    ;;
  home)
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"home\",\"id\":\"home-$(date +%s)\"}" "$RELAY_URL"
    ;;
  push_route)
    route="${1:?usage: push_route <route-name>}"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"push_route\",\"id\":\"route-$(date +%s)\",\"route\":\"$route\"}" "$RELAY_URL"
    ;;
  tap)
    x="${1:?usage: tap <x> <y>}"
    y="${2:?usage: tap <x> <y>}"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"tap\",\"id\":\"tap-$(date +%s)\",\"x\":$x,\"y\":$y}" "$RELAY_URL"
    ;;
  swipe)
    x1="${1:?usage: swipe <x1> <y1> <x2> <y2>}"
    y1="${2:?usage: swipe <x1> <y1> <x2> <y2>}"
    x2="${3:?usage: swipe <x1> <y1> <x2> <y2>}"
    y2="${4:?usage: swipe <x1> <y1> <x2> <y2>}"
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"swipe\",\"id\":\"swipe-$(date +%s)\",\"x1\":$x1,\"y1\":$y1,\"x2\":$x2,\"y2\":$y2}" "$RELAY_URL"
    ;;
  db_tables)
    python3.13 "$BRIDGE_DIR/ws-agent.py" "{\"type\":\"db_list_tables\",\"id\":\"dbt-$(date +%s)\"}" "$RELAY_URL"
    ;;
  relay_status)
    # For Cloudflare, hit the /state endpoint.
    if [[ "$RELAY_URL" == *"wss://"* ]] || [[ "$RELAY_URL" == *"https://"* ]]; then
      STATE_URL="${RELAY_URL/wss:\/\//https:\/\/}"
      STATE_URL="${STATE_URL/ws:\/\//http:\/\/}"
      curl -s --max-time 5 "${STATE_URL%/}/state" | python3.13 -m json.tool 2>/dev/null || echo "Cannot reach relay at $STATE_URL"
    else
      curl -s --max-time 3 http://localhost:3000/api/test-relay | python3.13 -m json.tool
    fi
    ;;
  help|*)
    cat <<EOF
ANI-KUTA test-controller agent helper (WebSocket v4 — Cloudflare Workers).

Env var:
  RELAY_URL  WebSocket relay URL (default: ws://127.0.0.1:3030/)
             For Cloudflare: export RELAY_URL="wss://anikuta-relay.xxx.workers.dev/"

Commands:
  send '<json>'              Send a raw command JSON.
  ping                       Smoke test — ping → pong (device info).
  get_state                  UI state + accessibility tree + screenshot.
  screenshot                 Capture a screenshot.
  back / home                Press Back / Home.
  push_route <route>         Navigate to a named route.
  tap <x> <y>                Tap at coordinates.
  swipe <x1> <y1> <x2> <y2>  Swipe.
  db_tables                  List all DB tables.
  relay_status               Check relay + phone status.

Data files:
  data/results/<id>.json     result JSONs
  data/screenshots/<id>.png  screenshot PNGs
EOF
    ;;
esac
