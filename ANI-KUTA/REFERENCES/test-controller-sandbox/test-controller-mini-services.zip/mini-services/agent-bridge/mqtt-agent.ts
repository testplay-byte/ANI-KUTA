/**
 * ANI-KUTA Test Controller — agent-side one-shot MQTT client (D-198 v2).
 *
 * Connects to the public MQTT broker, publishes a command, waits for the result
 * (+ screenshot if any), writes them to local files, then disconnects.
 *
 * One-shot: connect → subscribe → publish → wait → disconnect. No persistent process.
 * All within a single Bash tool call (the sandbox kills background processes between calls,
 * so a one-shot script is the only reliable approach).
 *
 * Usage:
 *   bun mqtt-agent.ts '<command-json>'
 *
 * Output:
 *   - stdout: the TestResult JSON (for the agent to read via `cat` or capture).
 *   - stderr: diagnostic messages (saved to /tmp/mqtt-agent-<id>.log).
 *   - File: data/results/<id>.json (the result, for direct Read tool access).
 *   - File: data/screenshots/<id>.png (the screenshot, if any — for VLM analysis).
 *
 * Topics (must match TestControllerConstants.kt):
 *   - Publish:   anikuta/test/v1/cmd          (TestCommand JSON)
 *   - Subscribe: anikuta/test/v1/result        (TestResult JSON)
 *   - Subscribe: anikuta/test/v1/shot/#        (JPEG bytes, topic = shot/<commandId>)
 */
import mqtt from "mqtt";
import { writeFileSync, mkdirSync } from "fs";
import path from "path";

const BROKER_URI = "wss://broker.hivemq.com:8884/mqtt";
const CMD_TOPIC = "anikuta/test/v1/cmd";
const RESULT_TOPIC = "anikuta/test/v1/result";
const SHOT_TOPIC_PREFIX = "anikuta/test/v1/shot/";

const DATA_DIR = path.join(import.meta.dir, "..", "data");
const RESULT_DIR = path.join(DATA_DIR, "results");
const SHOT_DIR = path.join(DATA_DIR, "screenshots");
mkdirSync(RESULT_DIR, { recursive: true });
mkdirSync(SHOT_DIR, { recursive: true });

// ── Parse the command from argv ──
const commandJson = process.argv[2];
if (!commandJson) {
  console.error("Usage: bun mqtt-agent.ts '<command-json>'");
  process.exit(1);
}
let command: any;
try {
  command = JSON.parse(commandJson);
} catch (e) {
  console.error("Invalid JSON:", e.message);
  process.exit(1);
}
if (!command.id) {
  command.id = `cmd-${Date.now()}`;
}
const commandId = command.id;
console.error(`[agent] command id=${commandId} type=${command.type || "?"}`);

// ── Connect to the broker ──
const clientId = `anikuta-agent-${Date.now()}`;
const client = mqtt.connect(BROKER_URI, {
  clientId,
  clean: true,
  connectTimeout: 10_000,
  keepalive: 30,
  reconnectPeriod: 0, // no auto-reconnect (one-shot)
});

let resultReceived = false;
let screenshotReceived = false;
let screenshotTimeout: NodeJS.Timeout | null = null;

// ── On connect: subscribe + publish ──
client.on("connect", () => {
  console.error(`[agent] connected to broker (clientId=${clientId})`);
  // Subscribe to the result topic + screenshot wildcard.
  client.subscribe(RESULT_TOPIC, { qos: 1 }, (err) => {
    if (err) {
      console.error("[agent] subscribe to result topic failed:", err.message);
      cleanup(1);
    }
  });
  client.subscribe(SHOT_TOPIC_PREFIX + "#", { qos: 1 }, (err) => {
    if (err) {
      console.error("[agent] subscribe to shot topic failed:", err.message);
      cleanup(1);
    }
  });
  // Publish the command.
  client.publish(CMD_TOPIC, JSON.stringify(command), { qos: 1 }, (err) => {
    if (err) {
      console.error("[agent] publish failed:", err.message);
      cleanup(1);
    }
    console.error(`[agent] command published to ${CMD_TOPIC}`);
  });
});

// ── On message: handle result or screenshot ──
client.on("message", (topic, message) => {
  if (topic === RESULT_TOPIC) {
    // Check if this result matches our command ID.
    try {
      const result = JSON.parse(message.toString());
      if (result.id !== commandId) {
        // Not our result — ignore (could be from a concurrent agent).
        return;
      }
      resultReceived = true;
      // Write to file for direct Read tool access.
      writeFileSync(path.join(RESULT_DIR, `${commandId}.json`), JSON.stringify(result, null, 2));
      // Print to stdout for capture.
      console.log(JSON.stringify(result));
      console.error(`[agent] result received (ok=${result.ok}, type=${result.type})`);
      // If the result indicates a screenshot was captured, wait a moment for it.
      const hasScreenshot =
        result.type === "screenshot_ref" ||
        (result.type === "state" && result.hasScreenshot === true);
      if (hasScreenshot && !screenshotReceived) {
        console.error("[agent] waiting up to 5s for screenshot…");
        screenshotTimeout = setTimeout(() => {
          console.error("[agent] screenshot not received within 5s — proceeding without it");
          cleanup(0);
        }, 5_000);
      } else {
        cleanup(0);
      }
    } catch (e) {
      console.error("[agent] failed to parse result:", e.message);
      cleanup(1);
    }
  } else if (topic.startsWith(SHOT_TOPIC_PREFIX)) {
    const shotId = topic.slice(SHOT_TOPIC_PREFIX.length);
    if (shotId !== commandId) return; // not our screenshot
    screenshotReceived = true;
    writeFileSync(path.join(SHOT_DIR, `${commandId}.png`), message);
    console.error(`[agent] screenshot received (${message.length} bytes) → data/screenshots/${commandId}.png`);
    if (resultReceived) {
      // Both result + screenshot received — done.
      if (screenshotTimeout) clearTimeout(screenshotTimeout);
      cleanup(0);
    }
  }
});

client.on("error", (err) => {
  console.error("[agent] MQTT error:", err.message);
  cleanup(1);
});

client.on("offline", () => {
  console.error("[agent] MQTT offline");
});

// ── Timeout: if no result within 30s, exit with error ──
const globalTimeout = setTimeout(() => {
  if (!resultReceived) {
    console.error(`[agent] timeout (30s) — no result received for command ${commandId}`);
    console.error("[agent] the phone may be offline, the AccessibilityService may not be enabled,");
    console.error("[agent] or the MQTT broker may be unreachable. Check:");
    console.error("[agent]   1. Is the app installed + the AccessibilityService enabled?");
    console.error("[agent]   2. Is the phone connected to the internet?");
    console.error("[agent]   3. Is the HiveMQ public broker up? (try wss://broker.emqx.io:8084/mqtt as fallback)");
    cleanup(1);
  }
}, 30_000);

// ── Cleanup ──
function cleanup(code: number) {
  clearTimeout(globalTimeout);
  if (screenshotTimeout) clearTimeout(screenshotTimeout);
  try {
    client.end(true); // force disconnect
  } catch {}
  setTimeout(() => process.exit(code), 200);
}
