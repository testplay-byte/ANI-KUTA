/**
 * ANI-KUTA Agent Bridge — Bun HTTP relay (D-198 transport).
 *
 * Connects the AI agent (sandbox, this machine) to the ANI-KUTA test-controller (phone).
 * The phone long-polls GET /poll for commands; the agent enqueues via POST /cmd (localhost).
 * Results + screenshots flow back: phone POSTs them, agent reads them via GET /result/:id +
 * GET /screenshot/:id.
 *
 * URL discovery (hybrid): the agent publishes ONE ntfy.sh message to topic
 * `anikuta-debug-bridge-v1` containing {relayUrl, token} at session start. The phone
 * (subscribed via SSE) picks it up + starts polling this relay.
 *
 * Auth: bearer token. Generated at startup if BRIDGE_TOKEN env is unset, written to
 * data/.token (chmod 0600). Every request must carry ?token=T or Authorization: Bearer T.
 *
 * Endpoints (all require ?token=T unless noted):
 *   POST /cmd                       body=TestCommand JSON → enqueue. Returns {ok, id}.
 *   GET  /poll?deviceId=X           long-poll ≤25s for next command. Returns {command:{...}} or {empty:true}.
 *   POST /result                    body=TestResult JSON → store. Notifies waiting GET /result/:id.
 *   POST /screenshot/:id            body=JPEG bytes → store as data/screenshots/<id>.png.
 *   GET  /result/:id                long-poll ≤30s for a result. Returns the stored JSON or {empty:true}.
 *   GET  /screenshot/:id            → image/jpeg bytes.
 *   GET  /state                     → {deviceOnline, lastSeen, queueDepth, token: "<masked>"}.
 *
 * Port: 3030 (avoids 3000 Next.js + 3003 websocket example).
 * Reachable from the phone via the sandbox gateway: https://PUBLIC_URL/?XTransformPort=3030
 * (Caddy's XTransformPort rule is generic — verified to forward any port).
 *
 * File storage (so the agent can read results directly via the Read tool, not just HTTP):
 *   data/commands/<id>.json
 *   data/results/<id>.json
 *   data/screenshots/<id>.png
 */
import { createServer } from "http";
import { randomUUID } from "crypto";
import { mkdirSync, readFileSync, writeFileSync, existsSync, statSync } from "fs";
import path from "path";

const PORT = Number(process.env.BRIDGE_PORT ?? 3030);
const DATA = path.join(import.meta.dir, "..", "data");
const CMD_DIR = path.join(DATA, "commands");
const RESULT_DIR = path.join(DATA, "results");
const SHOT_DIR = path.join(DATA, "screenshots");
[CMD_DIR, RESULT_DIR, SHOT_DIR].forEach((d) => mkdirSync(d, { recursive: true }));

// ── Token ──
const TOKEN = process.env.BRIDGE_TOKEN ?? randomUUID().replace(/-/g, "");
writeFileSync(path.join(DATA, ".token"), TOKEN, { mode: 0o600 });
console.log(`[bridge] token=${TOKEN} (also written to data/.token)`);

// ── State ──
const queue: string[] = []; // pending command IDs (FIFO)
const cmdWaiters: Array<(c: any) => void> = []; // phone long-polls waiting for a command
const resultWaiters = new Map<string, Array<(r: any) => void>>(); // commandId → agent long-polls
let lastSeen = 0;
let deviceOnline = false;
const ipCount = new Map<string, { n: number; t: number }>();

// ── Helpers ──
function auth(req: any): boolean {
  const u = new URL(req.url, "http://x");
  const t =
    u.searchParams.get("token") ??
    (req.headers["authorization"] ?? "").replace(/^Bearer\s+/i, "");
  return t === TOKEN;
}
function cors(res: any) {
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type, authorization");
}
function rateLimit(req: any): boolean {
  const ip = req.socket.remoteAddress ?? "?";
  const now = Date.now();
  const e = ipCount.get(ip) ?? { n: 0, t: now };
  if (now - e.t > 60_000) {
    e.n = 0;
    e.t = now;
  }
  e.n++;
  ipCount.set(ip, e);
  return e.n <= 120; // 120 req/min/IP (generous — long-polls count as 1)
}
function json(res: any, code: number, body: any) {
  res.writeHead(code, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
}
function readBody(req: any): Promise<Buffer> {
  return new Promise((resolve) => {
    const chunks: Buffer[] = [];
    req.on("data", (c: Buffer) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks)));
  });
}

// ── Server ──
const server = createServer(async (req: any, res: any) => {
  cors(res);
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }
  if (!auth(req)) return json(res, 401, { error: "bad token" });
  if (!rateLimit(req)) return json(res, 429, { error: "rate limit" });

  const u = new URL(req.url, "http://x");
  const p = u.pathname;

  // POST /cmd — agent enqueues a command.
  if (req.method === "POST" && p === "/cmd") {
    const body = (await readBody(req)).toString("utf8");
    let cmd: any;
    try {
      cmd = JSON.parse(body);
    } catch {
      return json(res, 400, { error: "invalid JSON" });
    }
    if (!cmd.id) cmd.id = randomUUID();
    writeFileSync(path.join(CMD_DIR, `${cmd.id}.json`), JSON.stringify(cmd));
    queue.push(cmd.id);
    const w = cmdWaiters.shift();
    if (w) w(cmd);
    return json(res, 200, { ok: true, id: cmd.id });
  }

  // GET /poll?deviceId=X — phone long-polls for a command (≤25s).
  if (req.method === "GET" && p === "/poll") {
    lastSeen = Date.now();
    deviceOnline = true;
    const id = queue.shift();
    if (id) {
      const cmd = JSON.parse(readFileSync(path.join(CMD_DIR, `${id}.json`), "utf8"));
      return json(res, 200, { command: cmd });
    }
    const waiter = (c: any) => json(res, 200, { command: c });
    cmdWaiters.push(waiter);
    const to = setTimeout(() => {
      const i = cmdWaiters.indexOf(waiter);
      if (i >= 0) cmdWaiters.splice(i, 1);
      json(res, 200, { empty: true });
    }, 25_000);
    // Replace the waiter so it also cancels the timeout when resolved.
    cmdWaiters[cmdWaiters.length - 1] = (c: any) => {
      clearTimeout(to);
      waiter(c);
    };
    return;
  }

  // POST /result — phone posts a TestResult JSON.
  if (req.method === "POST" && p === "/result") {
    const body = (await readBody(req)).toString("utf8");
    let result: any;
    try {
      result = JSON.parse(body);
    } catch {
      return json(res, 400, { error: "invalid JSON" });
    }
    if (!result.id) return json(res, 400, { error: "missing id" });
    writeFileSync(
      path.join(RESULT_DIR, `${result.id}.json`),
      JSON.stringify({ ...result, ts: Date.now() }),
    );
    const ws = resultWaiters.get(result.id) ?? [];
    ws.forEach((fn) => fn(result));
    resultWaiters.delete(result.id);
    return json(res, 200, { ok: true });
  }

  // POST /screenshot/:id — phone posts JPEG bytes.
  if (req.method === "POST" && p.startsWith("/screenshot/")) {
    const id = p.split("/").pop()!;
    const body = await readBody(req);
    if (body.length === 0) return json(res, 400, { error: "empty body" });
    writeFileSync(path.join(SHOT_DIR, `${id}.png`), body);
    return json(res, 200, { ok: true, id, bytes: body.length });
  }

  // GET /result/:id — agent long-polls for a result (≤30s).
  if (req.method === "GET" && p.startsWith("/result/")) {
    const id = p.split("/").pop()!;
    const f = path.join(RESULT_DIR, `${id}.json`);
    if (existsSync(f)) return json(res, 200, JSON.parse(readFileSync(f, "utf8")));
    const waiter = (r: any) => json(res, 200, r);
    if (!resultWaiters.has(id)) resultWaiters.set(id, []);
    resultWaiters.get(id)!.push(waiter);
    const to = setTimeout(() => {
      const arr = resultWaiters.get(id) ?? [];
      const i = arr.indexOf(waiter);
      if (i >= 0) arr.splice(i, 1);
      if (!existsSync(f)) json(res, 200, { empty: true, id });
    }, 30_000);
    // Replace so it cancels the timeout.
    const arr = resultWaiters.get(id)!;
    arr[arr.length - 1] = (r: any) => {
      clearTimeout(to);
      waiter(r);
    };
    return;
  }

  // GET /screenshot/:id — agent downloads the PNG.
  if (req.method === "GET" && p.startsWith("/screenshot/")) {
    const id = p.split("/").pop()!;
    const f = path.join(SHOT_DIR, `${id}.png`);
    if (!existsSync(f)) {
      res.writeHead(404);
      return res.end();
    }
    const buf = readFileSync(f);
    res.writeHead(200, {
      "content-type": "image/jpeg",
      "content-length": buf.length,
      "access-control-allow-origin": "*",
    });
    return res.end(buf);
  }

  // GET /state — health + device status.
  if (req.method === "GET" && p === "/state") {
    return json(res, 200, {
      deviceOnline,
      lastSeen,
      queueDepth: queue.length,
      token: TOKEN.slice(0, 4) + "…", // masked (agent reads full token from data/.token)
    });
  }

  res.writeHead(404, { "content-type": "application/json" });
  res.end(JSON.stringify({ error: "not found", path: p }));
});

server.listen(PORT, () => {
  console.log(`[bridge] listening on :${PORT}`);
  console.log(`[bridge] data dir: ${DATA}`);
});

// Device-online timeout (if no poll in 60s, mark offline).
setInterval(() => {
  if (Date.now() - lastSeen > 60_000) deviceOnline = false;
}, 5_000);

// Cleanup old results/screenshots (>1h) to avoid disk bloat.
setInterval(() => {
  const cutoff = Date.now() - 3_600_000;
  for (const dir of [RESULT_DIR, SHOT_DIR, CMD_DIR]) {
    try {
      const { readdirSync } = require("fs");
      for (const f of readdirSync(dir)) {
        const fp = path.join(dir, f);
        try {
          if (statSync(fp).mtimeMs < cutoff) {
            require("fs").unlinkSync(fp);
          }
        } catch {}
      }
    } catch {}
  }
}, 600_000);
