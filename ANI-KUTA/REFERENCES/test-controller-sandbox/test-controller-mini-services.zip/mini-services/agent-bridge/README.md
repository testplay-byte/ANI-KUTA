# ANI-KUTA Agent Bridge

Bun HTTP relay between the AI agent (sandbox) and the ANI-KUTA test-controller (phone).

**Transport layer** of the autonomous test-controller system (D-197/D-198). The phone runs a debug-only `AccessibilityService` that long-polls this relay for commands + posts back results + screenshots. The agent (sandbox) enqueues commands via `localhost:3030` + reads results either via HTTP or directly from `data/results/<id>.json` (local files).

## Architecture (hybrid transport — D-198)

```
Agent (sandbox, Bash)              Bun relay (:3030)              Phone (ANIKUTA app)
   │                                    │                              │
   │ POST /cmd?token=T  (localhost)     │                              │
   ├───────────────────────────────────►│                              │
   │                                    │ queue.push(cmdId)            │
   │                                    │◄──── GET /poll?token=T ──────┤  (long-poll ≤25s)
   │                                    │────── {command:{...}} ──────►│
   │                                    │                              │ execute
   │                                    │◄── POST /screenshot/:id ─────┤  (JPEG bytes)
   │                                    │◄── POST /result ──────────────┤  (TestResult JSON)
   │ GET /result/:id  (long-poll ≤30s)  │                              │
   ├───────────────────────────────────►│                              │
   │◄──────── {result JSON} ────────────┤                              │
   │ GET /screenshot/:id                │                              │
   ├───────────────────────────────────►│                              │
   │◄──────── image/jpeg bytes ─────────┤                              │
```

**URL discovery**: the agent publishes ONE ntfy.sh message to topic `anikuta-debug-bridge-v1` containing `{relayUrl, token, sessionId, expires}` at session start. The phone (subscribed via SSE since app launch) picks it up + starts polling this relay.

## Quick start

```bash
cd /home/z/my-project/mini-services/agent-bridge
./agent.sh start                 # starts the relay on :3030 (background, bun --hot)
./agent.sh token                 # prints the relay token (also in data/.token)
./agent.sh state                 # is the phone connected? queue depth?

# Send a command + read the result:
./agent.sh send '{"type":"ping"}'
# → prints the commandId
./agent.sh result <commandId>
# → prints the TestResult JSON

# Get the UI state + screenshot:
./agent.sh get_state
# → prints the State JSON + saves the screenshot to /tmp/state-<id>.png
```

## Endpoint reference

All endpoints require `?token=T` (or `Authorization: Bearer T`). Token is generated at startup if `BRIDGE_TOKEN` env is unset, written to `data/.token` (chmod 0600).

| Method | Path | Body | Returns |
|---|---|---|---|
| POST | `/cmd` | TestCommand JSON | `{ok, id}` |
| GET | `/poll?deviceId=X` | — | `{command:{...}}` or `{empty:true}` (long-poll ≤25s) |
| POST | `/result` | TestResult JSON | `{ok}` |
| POST | `/screenshot/:id` | JPEG bytes | `{ok, id, bytes}` |
| GET | `/result/:id` | — | result JSON or `{empty:true}` (long-poll ≤30s) |
| GET | `/screenshot/:id` | — | `image/jpeg` bytes |
| GET | `/state` | — | `{deviceOnline, lastSeen, queueDepth}` |

## File storage (so the agent can read results directly)

- `data/commands/<id>.json` — enqueued commands.
- `data/results/<id>.json` — results posted by the phone.
- `data/screenshots/<id>.png` — screenshots posted by the phone.
- `data/.token` — the auth token (chmod 0600).
- `data/relay.log` — relay stdout/stderr (when started via `agent.sh start`).

The agent can `cat data/results/<id>.json` directly (no HTTP round-trip) — useful for scripting. Screenshots can be analyzed via the **VLM skill** (z-ai-web-dev-sdk) by reading the PNG file.

## Phone-side URL discovery (ntfy bootstrap)

At session start, the agent publishes ONE message to `ntfy.sh/anikuta-debug-bridge-v1`:

```bash
curl -H "Title: ANI-KUTA bridge" \
  -d "{\"relayUrl\":\"https://SANDBOX_PUBLIC_URL/?XTransformPort=3030\",\"token\":\"$TOKEN\",\"sessionId\":\"$(uuidgen)\",\"expires\":$(($(date +%s)+3600))}" \
  https://ntfy.sh/anikuta-debug-bridge-v1
```

The phone (subscribed to the topic via SSE since app launch) receives this, validates `expires > now`, caches `relayUrl` + `token` in `app_settings` (keys `debug.test.relay_url` + `debug.test.relay_token`), and starts long-polling the relay.

**Fallback** (if ntfy is down): the user pastes `https://SANDBOX_PUBLIC_URL/?XTransformPort=3030` + the token into the app's Test settings screen.

## Security

- ntfy topics are public (CORE_RULES §11). The bootstrap message is readable by anyone who guesses `anikuta-debug-bridge-v1`. Mitigations: per-session rotating token (useless after session ends) + `expires` field (replay protection). Optional 6-digit PIN second factor (`debug.test.pin` setting).
- The relay URL is public. Mitigations: bearer token on every request + per-IP rate limit (120 req/min).
- The relay is debug-only tooling — never deployed to production. Removed before the app ships (the test-controller module is `debugImplementation`; the relay is a sandbox-side tool).

## Cleanup

Results + screenshots older than 1 hour are auto-deleted (the relay runs a cleanup interval). The agent can also `rm -rf data/*` between sessions.
