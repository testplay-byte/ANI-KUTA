#!/usr/bin/env python3.13
"""
ANI-KUTA Test Controller — agent-side one-shot MQTT client (D-198 v2.1).

Connects to the public MQTT broker, publishes a command, waits for the result
(+ screenshot if any), writes them to local files, then disconnects.

**Broker fallback** (D-198 v2.1): tries the SAME brokers in the SAME order as the
phone's MqttBridge.kt — so the agent + phone converge on the same broker. The phone
picks the first broker that connects + stays on it; the agent tries each broker in
order, waits for a response, moves to the next if no response.

One-shot: connect → subscribe → publish → wait → disconnect. No persistent process.

Usage:
    python3.13 mqtt-agent.py '<command-json>'

Output:
    - stdout: the TestResult JSON (for the agent to read).
    - stderr: diagnostic messages.
    - File: data/results/<id>.json (the result, for direct Read tool access).
    - File: data/screenshots/<id>.png (the screenshot, if any — for VLM analysis).
"""
import json
import os
import sys
import time
import uuid
import threading
from pathlib import Path

import paho.mqtt.client as mqtt

# Broker fallback list — MUST match MqttBridge.kt's BROKERS list (same order).
BROKERS = [
    {"label": "HiveMQ WSS", "host": "broker.hivemq.com", "port": 8884, "tls": True},
    {"label": "EMQX WSS",   "host": "broker.emqx.io",   "port": 8084, "tls": True},
    {"label": "EMQX WS",    "host": "broker.emqx.io",   "port": 8083, "tls": False},
    {"label": "HiveMQ WS",  "host": "broker.hivemq.com", "port": 8000, "tls": False},
]
MQTT_PATH = "/mqtt"
CMD_TOPIC = "anikuta/test/v1/cmd"
RESULT_TOPIC = "anikuta/test/v1/result"
SHOT_TOPIC_PREFIX = "anikuta/test/v1/shot/"

# Per-broker response timeout (seconds). The phone might be on any of the 4 brokers;
# we try each in turn. Total max wait: 4 × 18s = 72s. Bumped from 12s → 18s to match
# the phone's 15s connect timeout + give the command execution time to complete.
PER_BROKER_TIMEOUT = 18

SCRIPT_DIR = Path(__file__).parent.resolve()
DATA_DIR = SCRIPT_DIR / "data"
RESULT_DIR = DATA_DIR / "results"
SHOT_DIR = DATA_DIR / "screenshots"
RESULT_DIR.mkdir(parents=True, exist_ok=True)
SHOT_DIR.mkdir(parents=True, exist_ok=True)


def try_broker(broker, command, command_id):
    """Try a single broker. Returns (result_dict, screenshot_bytes) or (None, None) on timeout."""
    result_holder = {"result": None, "screenshot": None, "done": False}
    lock = threading.Lock()

    def maybe_finish(client_obj):
        with lock:
            if result_holder["done"]:
                return
            result = result_holder["result"]
            if result is None:
                return
            result_type = result.get("type", "")
            has_screenshot = (
                result_type == "screenshot_ref"
                or (result_type == "state" and result.get("hasScreenshot") is True)
            )
            if has_screenshot and result_holder["screenshot"] is None:
                return  # Wait for the screenshot.
            result_holder["done"] = True
        try:
            client_obj.disconnect()
        except Exception:
            pass

    def on_connect(client_obj, userdata, flags, reason_code, properties):
        if reason_code == 0:
            client_obj.subscribe(RESULT_TOPIC, qos=1)
            client_obj.subscribe(SHOT_TOPIC_PREFIX + "#", qos=1)
            payload = json.dumps(command)
            client_obj.publish(CMD_TOPIC, payload, qos=1)
        else:
            print(f"[agent] {broker['label']}: connect failed (reason={reason_code})", file=sys.stderr)

    def on_message(client_obj, userdata, msg):
        topic = msg.topic
        if topic == RESULT_TOPIC:
            try:
                result = json.loads(msg.payload.decode("utf-8"))
            except Exception:
                return
            if result.get("id") != command_id:
                return
            with lock:
                result_holder["result"] = result
            maybe_finish(client_obj)
        elif topic.startswith(SHOT_TOPIC_PREFIX):
            shot_id = topic[len(SHOT_TOPIC_PREFIX):]
            if shot_id != command_id:
                return
            with lock:
                result_holder["screenshot"] = msg.payload
            maybe_finish(client_obj)

    client = mqtt.Client(
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
        client_id=f"anikuta-agent-{uuid.uuid4().hex[:8]}",
        transport="websockets",
    )
    client.ws_set_options(path=MQTT_PATH)
    if broker["tls"]:
        client.tls_set()
    client.on_connect = on_connect
    client.on_message = on_message

    try:
        client.connect(broker["host"], broker["port"], keepalive=30)
    except Exception as e:
        print(f"[agent] {broker['label']}: connect failed: {e}", file=sys.stderr)
        return (None, None)

    client.loop_start()
    start_time = time.time()
    while time.time() - start_time < PER_BROKER_TIMEOUT:
        with lock:
            if result_holder["done"]:
                break
        time.sleep(0.2)
    client.loop_stop()
    try:
        client.disconnect()
    except Exception:
        pass

    with lock:
        return (result_holder["result"], result_holder["screenshot"])


def main():
    if len(sys.argv) < 2:
        print("Usage: python3.13 mqtt-agent.py '<command-json>'", file=sys.stderr)
        sys.exit(1)

    command_json = sys.argv[1]
    try:
        command = json.loads(command_json)
    except json.JSONDecodeError as e:
        print(f"Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    if "id" not in command:
        command["id"] = f"cmd-{int(time.time() * 1000)}"

    command_id = command["id"]
    command_type = command.get("type", "?")
    print(f"[agent] command id={command_id} type={command_type}", file=sys.stderr)

    # Try each broker in order until we get a response.
    for i, broker in enumerate(BROKERS):
        print(f"[agent] trying {broker['label']} ({broker['host']}:{broker['port']})…", file=sys.stderr)
        result, screenshot = try_broker(broker, command, command_id)
        if result is not None:
            # Write result to file.
            result_path = RESULT_DIR / f"{command_id}.json"
            result_path.write_text(json.dumps(result, indent=2))
            # Write screenshot to file (if any).
            if screenshot is not None:
                shot_path = SHOT_DIR / f"{command_id}.png"
                shot_path.write_bytes(screenshot)
                print(f"[agent] screenshot received ({len(screenshot)} bytes) → {shot_path}", file=sys.stderr)
            # Print result to stdout.
            print(json.dumps(result))
            print(f"[agent] result received via {broker['label']} (ok={result.get('ok')}, type={result.get('type')})", file=sys.stderr)
            sys.exit(0)

    # All brokers exhausted — no response.
    print(f"[agent] timeout — no response from any of the {len(BROKERS)} brokers (tried each for {PER_BROKER_TIMEOUT}s)", file=sys.stderr)
    print("[agent] the phone may be offline, the AccessibilityService may not be enabled,", file=sys.stderr)
    print("[agent] or all brokers are blocked by the carrier.", file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
