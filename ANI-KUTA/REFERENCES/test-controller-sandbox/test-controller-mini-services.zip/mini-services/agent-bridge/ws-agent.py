#!/usr/bin/env python3
"""
ANI-KUTA Test Controller — agent-side one-shot WebSocket client (D-198 v4).

Connects to the Cloudflare Workers WebSocket relay, sends a command, waits for
the result (+ screenshot), writes to local files, disconnects.

The relay URL is the Cloudflare Workers URL (e.g., wss://anikuta-relay.xxx.workers.dev).
Set it via the RELAY_URL env var or pass it as the second argument.

Usage:
    python3.13 ws-agent.py '<command-json>' [relay-url]

Output:
    - stdout: the TestResult JSON.
    - stderr: diagnostic messages.
    - File: data/results/<id>.json
    - File: data/screenshots/<id>.png
"""
import asyncio
import base64
import json
import os
import sys
import time
from pathlib import Path

try:
    import websockets
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--break-system-packages", "websockets"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    import websockets

# Default relay URL: Cloudflare Workers (set via env var or pass as 2nd arg).
# Fallback to localhost for backwards compatibility with the Next.js relay.
DEFAULT_RELAY_URL = os.environ.get("RELAY_URL", "ws://127.0.0.1:3030/")
TIMEOUT_SEC = 30

SCRIPT_DIR = Path(__file__).parent.resolve()
DATA_DIR = SCRIPT_DIR / "data"
RESULT_DIR = DATA_DIR / "results"
SHOT_DIR = DATA_DIR / "screenshots"
RESULT_DIR.mkdir(parents=True, exist_ok=True)
SHOT_DIR.mkdir(parents=True, exist_ok=True)


async def send_command(command, relay_url):
    command_id = command.get("id", f"cmd-{int(time.time() * 1000)}")
    command["id"] = command_id

    relay_msg = {"kind": "command", **command}

    try:
        async with websockets.connect(relay_url, ping_interval=30, ping_timeout=10, close_timeout=5) as ws:
            await ws.send(json.dumps({"kind": "register", "role": "agent"}))
            await ws.send(json.dumps(relay_msg))
            print(f"[agent] command sent via {relay_url} (id={command_id})", file=sys.stderr)

            result = None
            screenshot_data = None
            start_time = time.time()

            while time.time() - start_time < TIMEOUT_SEC:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=TIMEOUT_SEC)
                except asyncio.TimeoutError:
                    print(f"[agent] timeout ({TIMEOUT_SEC}s) — no result received", file=sys.stderr)
                    return None, None

                msg_data = json.loads(msg)
                msg_kind = msg_data.get("kind", "")

                if msg_kind == "result" and msg_data.get("id") == command_id:
                    result = msg_data
                    result_type = result.get("type", "")
                    has_screenshot = (
                        result_type == "screenshot_ref"
                        or (result_type == "state" and result.get("hasScreenshot") is True)
                    )
                    if has_screenshot and screenshot_data is None:
                        continue
                    break
                elif msg_kind == "screenshot" and msg_data.get("id") == command_id:
                    screenshot_data = base64.b64decode(msg_data.get("data", ""))
                    if result is not None:
                        break
                elif msg_kind == "pong" and msg_data.get("id") == command_id:
                    result = msg_data
                    break

            if result is None:
                print(f"[agent] no result received within {TIMEOUT_SEC}s", file=sys.stderr)
                return None, None

            return result, screenshot_data

    except ConnectionRefusedError:
        print(f"[agent] cannot connect to relay at {relay_url}", file=sys.stderr)
        return None, None
    except Exception as e:
        print(f"[agent] error: {type(e).__name__}: {e}", file=sys.stderr)
        return None, None


def main():
    if len(sys.argv) < 2:
        print("Usage: python3.13 ws-agent.py '<command-json>' [relay-url]", file=sys.stderr)
        sys.exit(1)

    command_json = sys.argv[1]
    relay_url = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_RELAY_URL

    try:
        command = json.loads(command_json)
    except json.JSONDecodeError as e:
        print(f"Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    result, screenshot = asyncio.run(send_command(command, relay_url))

    if result is None:
        sys.exit(1)

    command_id = result.get("id", command.get("id", "unknown"))
    result_path = RESULT_DIR / f"{command_id}.json"
    result_path.write_text(json.dumps(result, indent=2))

    if screenshot:
        shot_path = SHOT_DIR / f"{command_id}.png"
        shot_path.write_bytes(screenshot)
        print(f"[agent] screenshot saved ({len(screenshot)} bytes) → {shot_path}", file=sys.stderr)

    print(json.dumps(result))
    print(f"[agent] result received (ok={result.get('ok')}, type={result.get('type')})", file=sys.stderr)


if __name__ == "__main__":
    main()
